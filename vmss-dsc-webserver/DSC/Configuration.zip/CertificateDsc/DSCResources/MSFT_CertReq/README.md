# Description

The resource is used to request a new certificate from an certificate
authority.
